#include "fix64.h"

// vodi main(){
void mpc_main() {

  fixedptd INPUT_A_x;
  fixedptd INPUT_B_x;

  fixedptd OUTPUT_ceil = fixedptd_ceil(INPUT_A_x, INPUT_B_x);
}

